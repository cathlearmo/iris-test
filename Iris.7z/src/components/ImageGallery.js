import React from 'react';
import { useFetch } from './customHooks/useFetch.js';
import { useNavigate } from 'react-router-dom';
import './image.scss';

export const ImageGallery = () => {
    
    const [ url, setUrl] = React.useState('https://images-api.nasa.gov/search?q=star');
    const [ searchPhrase, setSearchPhrase ] = React.useState('');
    const { data }  = useFetch(url, []);
    const navigate = useNavigate();

    function doSearch() {
        setUrl(`https://images-api.nasa.gov/search?q=${searchPhrase}`);
    };

    const doLink = (item) => {
        const itemData = item.data && item.data.length ? item.data[0] : null;
        const imageItem = {
            image: item.links && item.links.length ? item.links[0].href : null,
            title: itemData && itemData.title,
            description: itemData && itemData.description,
            created: itemData && itemData.date_created
        };
        navigate('/image', {
            state: {
                imageItem
            }
        });
    }

    const handleKeyDown = (event) => {
        if (event.key === 'Enter') {
            setUrl(`https://images-api.nasa.gov/search?q=${searchPhrase}`);
        }
    };

    return (
        <div className="image-gallery">
            <h1>Image gallery</h1>

            <div className="input-field">   
                <input className="search-input" placeholder="Enter a search phrase..." type="text"
                    value={searchPhrase} onChange={(e) => setSearchPhrase(e.target.value)}
                    onKeyDown={handleKeyDown}/> 
                <input className="search-button" type="button" value="Search" onClick={doSearch} />
            </div>

            {Object.keys(data).length && data.collection.items.map((item, ind) => {
                const image = item.links && item.links.length ? item.links[0].href : null;
                const title = item.data && item.data.length ? item.data[0].title : null;
                return (
                    <div className="item" key={ind}>
                        <div className="image" onClick={() => doLink(item)}><img src={image}/></div>
                        <div>{title}</div>
                    </div>
                )
            })}
        </div>
    )
}