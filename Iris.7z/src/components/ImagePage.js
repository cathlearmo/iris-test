import {useLocation} from 'react-router-dom';

export const ImagePage = () => {
    const location = useLocation();
    const {imageItem} = location.state;
    return (
        <div>
            <h1>Image page</h1>
            <div><h3>{imageItem && `Title: ${imageItem.title}`}</h3></div>
            <div>{imageItem && imageItem.image ? <img src={imageItem.image} alt="image of planet"/> : null}</div>
            <div><h4>{imageItem && `Created: ${imageItem.created}`}</h4></div>
            <div>{imageItem && imageItem.description}</div>
        </div>
    )
}